package com.liyao.app.phonebodyguard;

import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.liyao.app.phonebodyguard.homepage_event.MenuItemEvent;
import com.liyao.app.phonebodyguard.service.MainService;

public class MainActivity extends Activity {

    private Intent mainServiceIntent;
    private MainService.MainServiceBinder mainServiceBinder;
    private ServiceConnection connection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mainServiceBinder = (MainService.MainServiceBinder)service;
        }
    };

    public void test(View v){
        mainServiceBinder.getData();

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.findViewById(R.id.homepage_rl_menu_left_1 ).setOnTouchListener(new MenuItemEvent(this));
        this.findViewById(R.id.homepage_rl_menu_right_1).setOnTouchListener(new MenuItemEvent(this));
        this.findViewById(R.id.homepage_rl_menu_left_2 ).setOnTouchListener(new MenuItemEvent(this));
        this.findViewById(R.id.homepage_rl_menu_right_2).setOnTouchListener(new MenuItemEvent(this));
        this.findViewById(R.id.homepage_rl_menu_left_3 ).setOnTouchListener(new MenuItemEvent(this));
        this.findViewById(R.id.homepage_rl_menu_right_3).setOnTouchListener(new MenuItemEvent(this));
        mainServiceIntent = new Intent(this, MainService.class);
        this.bindService(mainServiceIntent, connection, Service.BIND_AUTO_CREATE);



        //Log.v("$$$$",mainServiceBinder.getData());
        //Log.v("$$$$", mainServiceBindOperation.mainServiceBinder.getData());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.unbindService(connection);
//        this.stopService(mainService);
    }

//    public class MainServiceBindOperation1 implements ServiceConnection {
//
//        @Override
//        public void onServiceConnected(ComponentName name, IBinder service) {
//            Log.v("$$$$", "bind_onServiceConnected");
//            mainServiceBinder = (MainService.MainServiceBinder)service;
//        }
//
//        @Override
//        public void onServiceDisconnected(ComponentName name) {
//            Log.v("$$$$", "bind_onServiceDisconnected");
//
//        }
//    }
}
